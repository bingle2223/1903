create view v_x_1 as
select `homwork`.`score`.`sid` AS `sid`,count(`homwork`.`score`.`sid`) AS `count(sid)`
from `homwork`.`score`
where ((`homwork`.`score`.`cid` = 1) or (`homwork`.`score`.`cid` = 2))
group by `homwork`.`score`.`sid`
having (count(`homwork`.`score`.`sid`) = 2);

