create view v_c_s as
select `s`.`id`     AS `id`,
       `s`.`sid`    AS `sid`,
       `s`.`cid`    AS `cid`,
       `s`.`number` AS `number`,
       `c`.`name`   AS `name`,
       `c`.`tid`    AS `tid`
from (`homwork`.`course` `c`
       join `homwork`.`score` `s` on ((`s`.`cid` = `c`.`cid`)));

